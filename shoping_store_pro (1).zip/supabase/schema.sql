-- Shoping Store database schema for Supabase
-- Run this in Supabase SQL Editor. Review RLS policies before public launch.

create extension if not exists pgcrypto;

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  category text not null default 'Other',
  price numeric(12,2),
  merchant text not null default 'Other retailer',
  description text not null default '',
  image text not null default '',
  url text not null,
  keywords text not null default '',
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.user_roles (
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('admin')),
  created_at timestamptz not null default now(),
  primary key (user_id, role)
);

alter table public.products enable row level security;
alter table public.user_roles enable row level security;

create or replace function public.is_store_admin()
returns boolean language sql stable security definer
set search_path = public
as $$
  select exists (
    select 1 from public.user_roles
    where user_id = auth.uid() and role = 'admin'
  );
$$;

drop policy if exists "Anyone can read active products" on public.products;
create policy "Anyone can read active products"
on public.products for select
using (is_active = true or public.is_store_admin());

drop policy if exists "Admins insert products" on public.products;
create policy "Admins insert products"
on public.products for insert to authenticated
with check (public.is_store_admin());

drop policy if exists "Admins update products" on public.products;
create policy "Admins update products"
on public.products for update to authenticated
using (public.is_store_admin()) with check (public.is_store_admin());

drop policy if exists "Admins delete products" on public.products;
create policy "Admins delete products"
on public.products for delete to authenticated
using (public.is_store_admin());

drop policy if exists "Users can see own role" on public.user_roles;
create policy "Users can see own role"
on public.user_roles for select to authenticated
using (user_id = auth.uid());

-- IMPORTANT: after signing in once with Google, get your user UUID from
-- Supabase Dashboard > Authentication > Users, then run:
-- insert into public.user_roles(user_id, role)
-- values ('PASTE-YOUR-USER-UUID-HERE', 'admin')
-- on conflict do nothing;
--
-- Do NOT expose service_role key. Only use the anon/publishable key in browser.
