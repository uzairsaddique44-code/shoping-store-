SHOPING STORE PRO — QUICK SETUP
================================

What this package provides
- Lightweight responsive storefront (one HTML page; no build step)
- Search, category filters and sorting
- Product cards with affiliate link button that opens the retailer's product page
- Admin product editing backed by Supabase database
- Google sign-in integration code (requires your own OAuth setup)
- SEO title/slug/keyword draft helper
- SQL with row-level security for product data
- Sample/demo products clearly marked as placeholders

IMPORTANT: this is an integration-ready starter, not a fully connected live shop.
No Google account, Amazon Associates ID, Amazon API key, Shopify partnership, hosting account, or affiliate links were supplied, so these cannot be activated automatically. Sample listings do not contain working affiliate links.

SETUP A: Supabase database and Google sign-in
1. Create a free project at https://supabase.com/
2. Open SQL Editor and run supabase/schema.sql.
3. In Supabase Project Settings > API, copy Project URL and publishable/anon key.
4. Open index.html and replace:
   YOUR_SUPABASE_PROJECT_URL
   YOUR_SUPABASE_ANON_KEY
5. In Supabase Authentication > Providers, enable Google.
6. In Google Cloud Console, create an OAuth client ID for a Web application.
   Set the authorized JavaScript origin to your eventual website domain.
   Add the Supabase callback URL shown in Supabase's Google provider settings
   to Authorized redirect URIs.
7. Save the Google client ID and secret in Supabase's Google provider settings.
8. In Supabase Authentication > URL Configuration, set your Site URL and allowed
   redirect URLs to your actual domain.
9. Open the website and sign in once with Google.
10. In Supabase Dashboard > Authentication > Users, copy your user UUID.
    Run this SQL in Supabase SQL Editor (replace UUID):
    insert into public.user_roles(user_id, role)
    values ('PASTE-YOUR-USER-UUID-HERE', 'admin')
    on conflict do nothing;
11. Reload the site. Admin can now add real product listings and affiliate URLs.

SETUP B: Amazon affiliate products
1. Apply to the Amazon Associates program for the marketplace you plan to target.
2. Use your own approved Amazon Associates tracking ID and create product links
   using Amazon's permitted tools. If you want automated catalogue import, first
   verify your account's eligibility for Product Advertising API and obtain access.
3. Product API credentials must only be used on a secure server/edge function;
   never paste secret keys into index.html.
4. Add each approved affiliate URL to the product manager, or develop a server-side
   importer against the current official Amazon API terms. Amazon controls what
   product information/images/prices may be displayed and how often they refresh.
Official information: https://affiliate-program.amazon.com/

SETUP C: Shopify merchants
- Shopify is a platform used by many individual stores; it is not one universal
  affiliate product catalogue with one affiliate ID for every Shopify store.
- Join a specific merchant's affiliate program or an eligible Shopify Collabs
  partnership, and use the affiliate tracking URL the merchant/program provides.
- Paste that URL into each product listing. Only participating stores/programs
  can attribute eligible purchases to you.
Official information: https://help.shopify.com/en/manual/promoting-marketing/collabs

FAST / SEO NOTES
- Lightweight CSS and minimal JavaScript keep the storefront simple.
- Product images lazy-load.
- For a public launch, host over HTTPS, use a custom domain, add sitemap.xml,
  robots.txt, canonical URLs, real unique descriptions, structured product data
  where permitted, Search Console and analytics.
- Do not keyword-stuff. No tool can guarantee top Google ranking.
- Add privacy policy, contact page and affiliate disclosure.
- The retailer processes orders and payments when the shopper leaves through an
  affiliate link. Your site does not take payment or control shipping/returns.
- Commission depends on program approval, correct tracking links, program rules,
  customer eligibility and purchase conditions. Not every click or order earns commission.

Files
- index.html: storefront
- supabase/schema.sql: database schema and access policies
